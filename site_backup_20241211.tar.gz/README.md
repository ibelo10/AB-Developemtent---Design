# AB Development & Design

A modern, responsive landing page for AB Development & Design.

## Project Structure

- \ssets/\: Contains CSS, JavaScript, and image files
- \components/\: Reusable component files
- \scripts/\: Utility scripts

## Setup

1. Clone this repository
2. Open index.html in your browser
3. For development, use a local server
